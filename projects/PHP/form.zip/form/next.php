<?php

    $fName = $_POST['fname'];
    echo $fName . "<br>";

    $lName = $_POST['lname'];
    echo $lName . "<br>";

    $rName = $_POST['fav_race'];
    echo $rName . "<br>";

    $cName = $_POST['fav_class'];
    echo $cName . "<br>";

?>